//sets initial parameters
var earthS = 1.0;
var moonS = 1.2;
var darkS = .5;

var sensitivity = 0.5;

var dolphin1S = 0;